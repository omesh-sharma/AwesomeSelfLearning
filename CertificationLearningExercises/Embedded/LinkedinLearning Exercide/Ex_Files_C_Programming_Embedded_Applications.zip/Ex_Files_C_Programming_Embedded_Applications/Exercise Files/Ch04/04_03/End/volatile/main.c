#include <stdio.h>

volatile int a;
int	b;

char str[30];

int main(){
  a = 8;
  b = a*7;

  if(a == 8)
    printf("a equals 8!!!");
  else
    sprintf(str,"a is NOT 8!!!");
	
	a = 25;
	b = 39;
	
	while(1);
	return 0;
}

void SystemInit(){}
